package com.scoreservice.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;

import com.scoreservice.entity.Student;
import com.scoreservice.service.StudentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 对course表进行数据库操作
 */
@RestController
@Slf4j
@RequestMapping("/Student")
public class StudentController {

    @Autowired
    private StudentService studentService;
    /**
     * 判断表中是否有数据
     */
    @GetMapping("/exist")
    public boolean isDataExist(){
        List<Student> list = studentService.list();
        if (list.size()>0)
        {
            return true;
        }
        return false;
    }
    /**
     * 查询学生信息
     */
    @GetMapping("/list")
    public List<Student> list(){
        List<Student> list = studentService.list();
        log.info("查询学生",list);
        return list;
    }
    /**
     * 添加学生
     * @param student
     */
    @PutMapping
    public boolean add(@RequestBody Student student) {
        log.info("添加学生");
        if(studentService.save(student)) {
            return true;
        }
        return false;
    }
    /**
     * 删除学生
     */
    @DeleteMapping
    public boolean delete(int studentId) {
        log.info("删除学生");
        LambdaQueryWrapper<Student> objectLambdaQueryWrapper = new LambdaQueryWrapper<>();
        objectLambdaQueryWrapper.eq(Student::getId,studentId);
        boolean b= studentService.remove(objectLambdaQueryWrapper);
        return b;
    }

    /**
     * 查询
     * @param id
     * @return
     */
    @GetMapping("/{id}")
    public Student getbyid(@PathVariable Long id)
    {
        log.info("根据ID查询学生信息:"+id);
        Student byId = studentService.getById(id);
        return byId;
    }

    /**
     * 更新
     * @param student
     * @return
     */
    @PostMapping
    public boolean update(@RequestBody Student student)
    {
        log.info("根据id更新学生信息");
        boolean update = studentService.updateById(student);
        return update;
    }




}
