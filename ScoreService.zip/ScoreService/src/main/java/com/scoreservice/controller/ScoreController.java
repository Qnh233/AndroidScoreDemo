package com.scoreservice.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.scoreservice.entity.Course;
import com.scoreservice.entity.CourseSec;
import com.scoreservice.entity.Score;
import com.scoreservice.service.CourseService;
import com.scoreservice.service.ScoreService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * 对course表进行数据库操作
 */
@RestController
@Slf4j
@RequestMapping("/Score")
public class ScoreController {

    @Autowired
    private ScoreService scoreService;

    @Autowired
    private CourseService courseService;
    /**
     * 判断表中是否有数据
     */
    @GetMapping("/exist")
    public boolean isDataExist(){
        List<Score> list = scoreService.list();
        if (list.size()>0)
        {
            return true;
        }
        return false;
    }
    /**
     * 查询学生信息
     */
    @GetMapping("/list")
    public List<Score> list(){
        List<Score> list = scoreService.list();
        log.info("查询选课",list);
        return list;
    }
    /**
     * 添加或更新学生选课成绩（管理员）
     * @param score
     */
    @PutMapping
    public boolean add(@RequestBody Score score) {
        log.info("更新选课情况");
        LambdaQueryWrapper<Score> objectLambdaQueryWrapper = new LambdaQueryWrapper<>();
        objectLambdaQueryWrapper.eq(Score::getCourse_id,score.getCourse_id()).eq(Score::getStudent_id,score.getStudent_id());
        Score one = scoreService.getOne(objectLambdaQueryWrapper);
        if(one!=null)
        {
            boolean update = scoreService.saveOrUpdate(score,objectLambdaQueryWrapper);
            return update;
        }
        return false;
    }
    /**
     * 删除选课
     */
    @DeleteMapping
    public boolean delete(Long studentId,Integer courseId) {
        log.info("删除学生选课");
        LambdaQueryWrapper<Score> objectLambdaQueryWrapper = new LambdaQueryWrapper<>();
        objectLambdaQueryWrapper.eq(Score::getStudent_id,studentId).eq(Score::getCourse_id,courseId);
        boolean b= scoreService.remove(objectLambdaQueryWrapper);
        return b;
    }

    /**
     * 查询
     * @param id
     * @return
     */
    @GetMapping("/{id}")
    public List<CourseSec> getbyid(@PathVariable Long id)
    {
        log.info("根据学生ID查询选课信息:"+id);
        List<CourseSec> courseSecs = new ArrayList<>();
        LambdaQueryWrapper<Score> objectLambdaQueryWrapper = new LambdaQueryWrapper<>();
        LambdaQueryWrapper<Course> CLambdaQueryWrapper = new LambdaQueryWrapper<>();
        objectLambdaQueryWrapper.eq(Score::getStudent_id,id);
        List<Score> list = scoreService.list(objectLambdaQueryWrapper);
        for (Score s :
                list) {
            CLambdaQueryWrapper.eq(Course::getCourseId,s.getCourse_id());
            Course one = courseService.getOne(CLambdaQueryWrapper);
            CourseSec courseSec = new CourseSec(s.getCourse_id(), one.getCourseName(), one.getCredit(), s.getGrade(), one.getImageId());
            System.out.println(courseSec.getCourse_name());
            courseSecs.add(courseSec);
            CLambdaQueryWrapper.clear();
        }
        return courseSecs;
    }

    /**
     * 查询选课情况
     * @param studentid
     * @return
     */
    @GetMapping("/selected/{studentid}")
    public List<Course> Selected(@PathVariable Long studentid)
    {
//        select * from course where course_id not in" +
//        "(select course_id from score where student_id = ?)
        log.info("查询已选择的课程");
        LambdaQueryWrapper<Score> objectLambdaQueryWrapper = new LambdaQueryWrapper<>();
        objectLambdaQueryWrapper.eq(Score::getStudent_id,studentid);
        LambdaQueryWrapper<Course> courseLambdaQueryWrapper = new LambdaQueryWrapper<>();
        List<Score> list = scoreService.list(objectLambdaQueryWrapper);
        List<Course> Clist=new ArrayList<>();
        for (Score s :
                list) {
            courseLambdaQueryWrapper.eq(Course::getCourseId,s.getCourse_id());
            Course byId = courseService.getOne(courseLambdaQueryWrapper);
            log.info(byId.getCourseName());
            Clist.add(byId);
            courseLambdaQueryWrapper.clear();
        }
        return Clist;
    }

    /**
     * 查询未选课情况
     * @param studentid
     * @return
     */
    @GetMapping("/unselected/{studentid}")
    public List<Course> unselected(@PathVariable Long studentid)
    {
        log.info("查未选择的课程");
        QueryWrapper<Course> objectQueryWrapper = new QueryWrapper<>();
        objectQueryWrapper.notInSql("course_id","select course_id from score where student_id = "+studentid);
        List<Course> Clist=courseService.list(objectQueryWrapper);
        System.out.println(Clist);
        return Clist;
    }

    /**
     * 学生新选课
     * @param
     * @return
     */
    @PostMapping("addupdate/{studentid}/{courseid}")
    public boolean addupdate(@PathVariable Long studentid,@PathVariable Integer courseid)
    {
        log.info(studentid+"选课"+courseid);
        boolean save = scoreService.save(new Score(courseid, studentid, 0));
        return save;
    }

    /**
     * 更新 学生退课
     * @param
     * @return
     */
    @PostMapping("rmupdate/{studentid}/{courseid}")
    public boolean rmupdate(@PathVariable Long studentid,@PathVariable Integer courseid)
    {
        log.info(studentid+"退课"+courseid);
        LambdaQueryWrapper<Score> objectLambdaQueryWrapper = new LambdaQueryWrapper<>();
        objectLambdaQueryWrapper.eq(Score::getCourse_id,courseid).eq(Score::getStudent_id,studentid);
        boolean rm = scoreService.remove(objectLambdaQueryWrapper);
        return rm;
    }
}
