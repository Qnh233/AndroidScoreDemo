package com.scoreservice.controller;

import com.scoreservice.entity.Course;
import com.scoreservice.service.CourseService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 对course表进行数据库操作
 */
@RestController
@Slf4j
@RequestMapping(value = "/Course")
public class CourseController {

    @Autowired
    private CourseService courseService;
    /**
     * 判断表中是否有数据
     */
    @GetMapping("/exist")
    public boolean isDataExist(){
        List<Course> list = courseService.list();
        if (list.size()>0)
        {
            return true;
        }
        return false;
    }
    /**
     * 查询课程信息
     */
    @GetMapping("/list")
    public List<Course> getCourse(){
        List<Course> list = courseService.list();
        log.info("查询课程",list);
        return list;
    }
    /**
     * getbyid
     */
    @GetMapping("/{id}")
    public Course getbyid(@PathVariable(value = "id") Integer id)
    {
        log.info("根据ID查询学生信息:"+id);
        Course byId = courseService.getById(id);
        return byId;
    }
    /**
     * 添加课程
     */
    @PutMapping
    public boolean addCourse(@RequestBody Course course) {
        log.info("添加课程");
        if(courseService.save(course)) {
            return true;
        }
        return false;

    }
    /**
     * 删除课程,以课程id
     */
    @DeleteMapping
    public boolean deleteCourse(int courseId) {
        log.info("删除课程");
        LambdaQueryWrapper<Course> objectLambdaQueryWrapper = new LambdaQueryWrapper<>();
        objectLambdaQueryWrapper.eq(Course::getCourseId,courseId);
        boolean b=courseService.remove(objectLambdaQueryWrapper);
        return b;
    }


//    private Course parseCourse( ){
//
//        return ;
//    }


}
