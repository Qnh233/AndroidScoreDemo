package com.scoreservice.controller;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.scoreservice.entity.User;
import com.scoreservice.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


/**
 * 对course表进行数据库操作
 */
@RestController
@Slf4j
@RequestMapping(value = "/User")
public class UserController {

    @Autowired
    private UserService userService;
    /**
     * check
     */
    @PostMapping()
    public Boolean checkUser(@RequestBody User user)
    {
        log.info("根据ID查询check学生信息:"+user.getId()+":"+user.getPassword());
        QueryWrapper<User> userLambdaQueryWrapper = new QueryWrapper<>();
        userLambdaQueryWrapper.eq("id",user.getId()).eq("password",user.getPassword());
        User byId = userService.getOne(userLambdaQueryWrapper);
        if(byId!=null)
        {
            return true;
        }
        return false;
    }
    /**
     * 添加用户
     */
    @PutMapping
    public boolean addUser(@RequestBody User user) {
        log.info("添加或修改用户");
        QueryWrapper<User> userLambdaQueryWrapper = new QueryWrapper<User>();
        userLambdaQueryWrapper.eq("id",user.getId());
        if(userService.saveOrUpdate(user,userLambdaQueryWrapper)) {
            return true;
        }
        return false;
    }
}
