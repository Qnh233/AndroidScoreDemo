package com.scoreservice.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * 登录信息类
 */
@TableName(value ="user")
@Data
public class User {
    private Long id;
    private String password;
}
