package com.scoreservice.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * 学生实体类，id,name,sex,age,phone
 */
@TableName(value ="student")
@Data
@AllArgsConstructor
public class Student {
    private Long id;
    private String name;
    private String sex;
    private int age;
    private String phone;
    private String imageId;

}
