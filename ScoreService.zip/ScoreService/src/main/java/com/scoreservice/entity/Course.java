package com.scoreservice.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.context.annotation.Primary;

import java.lang.reflect.Type;

/**
 * 课程类，课程号，课程名，学分，图片id
 */
@TableName(value ="course")
@Data
@AllArgsConstructor
public class Course {
    private Integer courseId;
    private String courseName;
    private int credit;
    private String imageId;
}
