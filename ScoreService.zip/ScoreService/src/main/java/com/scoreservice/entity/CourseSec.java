package com.scoreservice.entity;

import lombok.Data;

/**
 * 展示学生选课及对应课程分数的类
 */
@Data
public class CourseSec {
    private int course_id;
    private  String course_name;
    private int credit;
    private int grade;
    private String imageId;
    public CourseSec(){

    }
    public CourseSec(int course_id,String course_name,int credit,int grade,String imageId){
        this.course_id=course_id;
        this.course_name = course_name;
        this.credit = credit;
        this.grade = grade;
        this.imageId = imageId;
    }
}
