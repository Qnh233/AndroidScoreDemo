package com.scoreservice.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * 选课信息类，课程Id,学生Id,分别对应各自表中的属性，有外键约束
 * 成绩grade为可空属性，即学生选课并未结课，结课后由管理员录入成绩
 * 学生无权限修改该表中的数据
 */
@TableName(value ="score")
@Data
@AllArgsConstructor
public class Score {
    private int course_id;
    private Long student_id;
    private int grade;
}
