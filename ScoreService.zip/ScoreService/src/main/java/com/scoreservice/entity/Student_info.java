package com.scoreservice.entity;


import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * 拆分学生信息的内部类，用于单项展示学生属性在RecycleView上
 */
@Data
@AllArgsConstructor
public class Student_info{
    private int image;
    private String info;

}
