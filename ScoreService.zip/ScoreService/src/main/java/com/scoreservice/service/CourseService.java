package com.scoreservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.scoreservice.entity.Course;
/**
* @author Xhao
* @description 针对表【course】的数据库操作Service
* @createDate 2023-05-19 10:07:27
*/
public interface CourseService extends IService<Course> {

}
