package com.scoreservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.scoreservice.entity.Course;
import com.scoreservice.entity.Score;
import org.apache.ibatis.annotations.Param;

import java.util.List;


/**
* @author Xhao
* @description 针对表【score】的数据库操作Service
* @createDate 2023-05-19 10:07:27
*/
public interface ScoreService extends IService<Score> {

}
