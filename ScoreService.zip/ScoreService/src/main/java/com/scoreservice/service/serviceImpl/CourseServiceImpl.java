package com.scoreservice.service.serviceImpl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.scoreservice.entity.Course;
import com.scoreservice.mapper.CourseMapper;
import com.scoreservice.service.CourseService;
import org.springframework.stereotype.Service;

/**
 * @author 必燃
 * @version 1.0
 * @create 2023-05-19 11:26
 */
@Service
public class CourseServiceImpl extends ServiceImpl<CourseMapper, Course> implements CourseService {
}
