package com.scoreservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.scoreservice.entity.Student;

/**
* @author Xhao
* @description 针对表【student】的数据库操作Service
* @createDate 2023-05-19 10:07:27
*/
public interface StudentService extends IService<Student> {

}
