package com.scoreservice.service.serviceImpl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.scoreservice.entity.Course;
import com.scoreservice.entity.Score;
import com.scoreservice.mapper.ScoreMapper;
import com.scoreservice.service.ScoreService;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Service;

import java.util.List;

/**
* @author Xhao
* @description 针对表【score】的数据库操作Service实现
* @createDate 2023-05-19 10:07:27
*/
@Service
public class ScoreServiceImpl extends ServiceImpl<ScoreMapper, Score>
implements ScoreService {


}
