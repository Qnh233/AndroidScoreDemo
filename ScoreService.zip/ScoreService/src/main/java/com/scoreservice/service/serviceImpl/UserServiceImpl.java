package com.scoreservice.service.serviceImpl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.scoreservice.entity.User;
import com.scoreservice.mapper.UserMapper;
import com.scoreservice.service.UserService;
import org.springframework.stereotype.Service;

/**
* @author Xhao
* @description 针对表【user】的数据库操作Service实现
* @createDate 2023-05-19 10:07:27
*/
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User>
implements UserService {

}
