package com.scoreservice.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.scoreservice.entity.Course;
import com.scoreservice.entity.Score;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
* @author Xhao
* @description 针对表【score】的数据库操作Mapper
* @createDate 2023-05-19 10:07:27
* @Entity Mybatis.domain.Score
*/
@Mapper
public interface ScoreMapper extends BaseMapper<Score> {


}
