package com.scoreservice.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.scoreservice.entity.Student;
import org.apache.ibatis.annotations.Mapper;

/**
* @author Xhao
* @description 针对表【student】的数据库操作Mapper
* @createDate 2023-05-19 10:07:27
* @Entity Mybatis.domain.Student
*/
@Mapper
public interface StudentMapper extends BaseMapper<Student> {


}
