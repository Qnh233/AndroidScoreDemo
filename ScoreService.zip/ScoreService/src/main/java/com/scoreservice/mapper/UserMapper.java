package com.scoreservice.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.scoreservice.entity.User;
import org.apache.ibatis.annotations.Mapper;

/**
* @author Xhao
* @description 针对表【user】的数据库操作Mapper
* @createDate 2023-05-19 10:07:27
* @Entity Mybatis.domain.User
*/
@Mapper
public interface UserMapper extends BaseMapper<User> {
}
