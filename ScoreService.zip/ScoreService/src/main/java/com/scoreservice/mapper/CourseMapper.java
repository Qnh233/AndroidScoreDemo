package com.scoreservice.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.scoreservice.entity.Course;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 必燃
 * @version 1.0
 * @create 2023-05-19 11:29
 */
@Mapper
public interface CourseMapper extends BaseMapper<Course> {
}
