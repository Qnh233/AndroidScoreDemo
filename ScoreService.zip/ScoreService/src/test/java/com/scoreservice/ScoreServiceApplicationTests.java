package com.scoreservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScoreServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
